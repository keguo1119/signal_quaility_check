-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Licensed to the public under the Apache License 2.0.



local io     = require "io"
local os     = require "os"
local table  = require "table"
local nixio  = require "nixio"
local fs     = require "nixio.fs"
local uci    = require "luci.model.uci"

local luci  = {}
luci.util   = require "luci.util"
luci.ip     = require "luci.ip"

local tonumber, ipairs, pairs, pcall, type, next, setmetatable, require, select =
        tonumber, ipairs, pairs, pcall, type, next, setmetatable, require, select


module "luci.sys"


function lteversion(num, newname)
        filename = "/usr/local/lte/back"..num.."/version"
        local file = io.open(filename, "r")
        if file then
                if newname == 1 then
                         local name = file:read("*line")
                         file:close()
                         return name
                else
                        local name = file:read("*line")
                        name = file:read("*line")
                         file:close()
                         return name
                end
        else
                return nil
        end
end

function myreboot()
	os.execute("ifconfig eth0 down ");  --shutdown the eth
	os.execute("ifconfig apcli0 down"); --shutdown the WIFI
	os.execute(" kill $(ps | grep app | grep -v grep | awk '{print $1}') ")
	os.execute("reboot > /dev/null 2>&1");
end

function pingtestwrtlte()
	return os.execute("ping -c1 192.168.8.2 >/dev/null 2>&1")
end


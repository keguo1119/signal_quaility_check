#!/bin/sh

mkdir -p /usr/local/lte/workspace/lteapp
echo " mkdir -p /usr/local/lte/workspace/lteapp"

ln -s //usr/local/lte/workspace/ /usr/local/lte/back1
echo "ln -s //usr/local/lte/workspace/ /usr/local/lte/back1"

mkdir -p  /usr/local/lte/workspace/luci
echo "mkdir -p  /usr/local/lte/workspace/luci"

mkdir -p /usr/lib/lua/luci/view/admin_version/
echo " mkdir -p /usr/lib/lua/luci/view/admin_version/"

mv version /usr/local/lte/workspace/
echo "mv version /usr/local/lte/workspace/"

mv app /usr/local/lte/workspace/lteapp
echo "mv app /usr/local/lte/workspace/lteapp"

cp  status.htm   flashops.htm  applyreboot.htm reboot.htm  /usr/lib/lua/luci/view/admin_version/
echo "cp  status.htm   flashops.htm  applyreboot.htm reboot.htm  /usr/lib/lua/luci    /view/admin_version/"

cp  version.lua  /usr/lib/lua/luci/controller/admin
echo " cp  version.lua  /usr/lib/lua/luci/controller/admin"

cp  sys.lua mysys.lua /usr/lib/lua/luci
cp  sysupgrade1 /sbin/

cp mysys.lua sys.lua  /usr/local/lte/workspace/luci/
cp root rc.local  /usr/local/lte/workspace/luci/

cp verupgrade.conf /lib/upgrade/

mv appmonitor.sh /usr/local/lte/workspace/luci/

mv rc.local /etc/
echo "change the rc.local"

mv root  /etc/crontabs/
echo "change the crontab"

mv libpthread.so.0 librt.so.0 /usr/lib/

rm -r /tmp/luci-indexcache  /tmp/luci-modulecache/

opkg install  zlib_1.2.8-1_ramips_24kec.ipk  libmagic_5.11-1_ramips_24kec.ipk file_5.11-1_ramips_24kec.ipk 

opkg install libncurses_5.9-1_ramips_24kec.ipk   minicom_2.7-1_ramips_24kec.ipk


